print("Semana No. 11: Ejercicio 2")

N=0
while N<=0:
 N=int(input("Ingrese un número mayor que 0: "))
 if N<0:
  print("El número ingresado debe ser mayor a 0")
  print()


suma_a= sum(1/i for i in range(1,N+1))
print("procedimiento a: ", suma_a)

suma_b=sum(1/(2 ** i) for i in range(1,N+1))
print("procedimiento b: ", suma_b)

x=int(input("Ingrese un valor entero para x: "))
a=int(input("Ingrese un valor entero para a: "))
n=int(input("Ingrese un valor entero para n: "))

suma_c = sum((x * k) * (a * (n - k)) for k in range(n + 1))
print("procedimeinto c:", suma_c)
